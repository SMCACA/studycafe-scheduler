import { useState } from "react";
import { Search, Plus, Edit2, Trash2, X, Users, CheckCircle, AlertTriangle } from "lucide-react";

// ============================================================
// 🔌 Supabase 연결 설정
// ------------------------------------------------------------
// 아래 두 줄 주석을 해제하고, .env 파일의 값으로 교체하세요.
// Supabase 대시보드 → Settings → API 에서 확인할 수 있어요.
// ============================================================
import { createClient } from '@supabase/supabase-js'
const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
)

// ============================================================
// 🧪 테스트용 샘플 데이터 (Supabase 연결 후 삭제 가능)
// ============================================================
const SAMPLE_STUDENTS = [
  {
    id: 1,
    name: "김민준",
    grade: "고1",
    school: "한빛고등학교",
    parent_name: "김영수",
    parent_phone: "010-1234-5678",
    student_phone: "010-9876-5432",
    memo: "수학 집중 관리 필요",
  },
  {
    id: 2,
    name: "이서연",
    grade: "중3",
    school: "푸른중학교",
    parent_name: "이정희",
    parent_phone: "010-2345-6789",
    student_phone: "010-8765-4321",
    memo: "",
  },
  {
    id: 3,
    name: "박준혁",
    grade: "고2",
    school: "별빛고등학교",
    parent_name: "박성민",
    parent_phone: "010-3456-7890",
    student_phone: "010-7654-3210",
    memo: "영어 약함",
  },
];

const GRADES = ["중1", "중2", "중3", "고1", "고2", "고3"];

// ============================================================
// 메인 컴포넌트: 학생 관리 페이지
// ============================================================
export default function StudentManagement() {
  const [students, setStudents] = useState(SAMPLE_STUDENTS);
  const [search, setSearch] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null); // null = 신규 등록, 값 있으면 = 수정
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);

  // 검색 필터: 이름·학교·학년으로 필터링
  const filteredStudents = students.filter(
    (s) =>
      s.name.includes(search) ||
      s.school.includes(search) ||
      s.grade.includes(search)
  );

  // 알림 메시지 표시 (2.5초 후 자동 사라짐)
  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2500);
  };

  const openAddModal = () => {
    setEditingStudent(null);
    setIsModalOpen(true);
  };

  const openEditModal = (student) => {
    setEditingStudent(student);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingStudent(null);
  };

  // ============================================================
  // 📌 학생 저장 (등록 or 수정)
  // ============================================================
  const handleSave = async (formData) => {
    setLoading(true);
    try {
      if (editingStudent) {
        // ─── 수정 ───────────────────────────────────────────
        // ✅ Supabase 연결 후: 아래 주석 해제 + 임시 코드 삭제
        const { error } = await supabase
          .from('students')
          .update(formData)
          .eq('id', editingStudent.id)
        if (error) throw error


        setStudents((prev) =>
          prev.map((s) =>
            s.id === editingStudent.id ? { ...s, ...formData } : s
          )
        );
        showToast(`${formData.name} 학생 정보가 수정되었습니다.`);
      } else {
        // ─── 신규 등록 ──────────────────────────────────────
        // ✅ Supabase 연결 후: 아래 주석 해제 + 임시 코드 삭제
        const { data, error } = await supabase
          .from('students')
          .insert(formData)
          .select()
          .single()
        if (error) throw error
        setStudents((prev) => [...prev, data])


        const newStudent = { ...formData, id: Date.now() };
        setStudents((prev) => [...prev, newStudent]);
        showToast(`${formData.name} 학생이 등록되었습니다.`);
      }
      closeModal();
    } catch (err) {
      console.error(err);
      showToast("오류가 발생했습니다. 다시 시도해주세요.", "error");
    } finally {
      setLoading(false);
    }
  };

  // ============================================================
  // 📌 학생 삭제
  // ============================================================
  const handleDelete = async () => {
    if (!deleteTarget) return;
    setLoading(true);
    try {
      // ✅ Supabase 연결 후: 아래 주석 해제 + 임시 코드 삭제
      // const { error } = await supabase
      //   .from('students')
      //   .delete()
      //   .eq('id', deleteTarget.id)
      // if (error) throw error


      setStudents((prev) => prev.filter((s) => s.id !== deleteTarget.id));
      showToast(`${deleteTarget.name} 학생이 삭제되었습니다.`, "error");
      setDeleteTarget(null);
    } catch (err) {
      console.error(err);
      showToast("삭제 중 오류가 발생했습니다.", "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* 토스트 알림 */}
      {toast && <Toast msg={toast.msg} type={toast.type} />}

      {/* 페이지 헤더 */}
      <div className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-slate-800">학생 관리</h1>
            <p className="text-sm text-slate-500 mt-0.5">
              총 {students.length}명 등록됨
            </p>
          </div>
          <button
            onClick={openAddModal}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-lg text-sm font-semibold transition-colors"
          >
            <Plus size={16} />
            학생 등록
          </button>
        </div>
      </div>

      {/* 메인 콘텐츠 */}
      <div className="max-w-6xl mx-auto px-6 py-6">
        {/* 검색창 */}
        <div className="relative mb-5 max-w-sm">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="이름, 학교, 학년으로 검색"
            className="w-full pl-9 pr-4 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* 학생 목록 테이블 */}
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                {["이름", "학년", "학교", "학부모", "학부모 전화", "학생 전화", "메모", "관리"].map(
                  (h) => (
                    <th
                      key={h}
                      className="text-left px-4 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wide whitespace-nowrap"
                    >
                      {h}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-16 text-slate-400">
                    <Users size={32} className="mx-auto mb-3 text-slate-300" />
                    {search
                      ? "검색 결과가 없습니다."
                      : "등록된 학생이 없습니다. 첫 학생을 등록해보세요!"}
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student) => (
                  <StudentRow
                    key={student.id}
                    student={student}
                    onEdit={() => openEditModal(student)}
                    onDelete={() => setDeleteTarget(student)}
                  />
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 등록/수정 모달 */}
      {isModalOpen && (
        <StudentModal
          student={editingStudent}
          onSave={handleSave}
          onClose={closeModal}
          loading={loading}
        />
      )}

      {/* 삭제 확인 다이얼로그 */}
      {deleteTarget && (
        <DeleteDialog
          student={deleteTarget}
          onConfirm={handleDelete}
          onClose={() => setDeleteTarget(null)}
          loading={loading}
        />
      )}
    </div>
  );
}

// ============================================================
// 학생 한 행 컴포넌트
// ============================================================
function StudentRow({ student, onEdit, onDelete }) {
  const gradeStyle = student.grade.startsWith("고")
    ? "bg-blue-50 text-blue-700"
    : "bg-green-50 text-green-700";

  return (
    <tr className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
      <td className="px-4 py-3 font-semibold text-slate-800">{student.name}</td>
      <td className="px-4 py-3">
        <span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-semibold ${gradeStyle}`}>
          {student.grade}
        </span>
      </td>
      <td className="px-4 py-3 text-slate-600">{student.school || "-"}</td>
      <td className="px-4 py-3 text-slate-600">{student.parent_name || "-"}</td>
      <td className="px-4 py-3 text-slate-600 font-mono text-xs">{student.parent_phone || "-"}</td>
      <td className="px-4 py-3 text-slate-600 font-mono text-xs">{student.student_phone || "-"}</td>
      <td className="px-4 py-3 text-slate-400 max-w-[150px] truncate">{student.memo || "-"}</td>
      <td className="px-4 py-3">
        <div className="flex gap-2">
          <button
            onClick={onEdit}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-slate-200 bg-white hover:border-blue-300 hover:text-blue-600 text-slate-600 text-xs font-semibold transition-colors"
          >
            <Edit2 size={12} />
            수정
          </button>
          <button
            onClick={onDelete}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-md border border-red-100 bg-red-50 hover:bg-red-100 text-red-500 text-xs font-semibold transition-colors"
          >
            <Trash2 size={12} />
            삭제
          </button>
        </div>
      </td>
    </tr>
  );
}

// ============================================================
// 등록/수정 모달 컴포넌트
// ============================================================
function StudentModal({ student, onSave, onClose, loading }) {
  const isEdit = !!student;
  const [form, setForm] = useState({
    name: student?.name || "",
    grade: student?.grade || "",
    school: student?.school || "",
    parent_name: student?.parent_name || "",
    parent_phone: student?.parent_phone || "",
    student_phone: student?.student_phone || "",
    memo: student?.memo || "",
  });
  const [errors, setErrors] = useState({});

  // 폼 값 업데이트 + 에러 초기화
  const set = (key, value) => {
    setForm((f) => ({ ...f, [key]: value }));
    if (errors[key]) setErrors((e) => ({ ...e, [key]: "" }));
  };

  // 필수 항목 검증
  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "이름을 입력해주세요";
    if (!form.grade) e.grade = "학년을 선택해주세요";
    return e;
  };

  const handleSubmit = () => {
    const e = validate();
    if (Object.keys(e).length > 0) {
      setErrors(e);
      return;
    }
    onSave(form);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-lg font-bold text-slate-800">
            {isEdit ? "학생 정보 수정" : "새 학생 등록"}
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors p-1">
            <X size={20} />
          </button>
        </div>

        {/* 입력 폼 */}
        <div className="px-6 py-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <FormField label="이름" required error={errors.name}>
              <input
                type="text"
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                placeholder="홍길동"
                className={`w-full px-3 py-2.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                  errors.name ? "border-red-400 bg-red-50" : "border-slate-200"
                }`}
              />
            </FormField>

            <FormField label="학년" required error={errors.grade}>
              <select
                value={form.grade}
                onChange={(e) => set("grade", e.target.value)}
                className={`w-full px-3 py-2.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white ${
                  errors.grade ? "border-red-400 bg-red-50" : "border-slate-200"
                }`}
              >
                <option value="">학년 선택</option>
                {GRADES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </FormField>
          </div>

          <FormField label="학교">
            <input
              type="text"
              value={form.school}
              onChange={(e) => set("school", e.target.value)}
              placeholder="한빛고등학교"
              className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </FormField>

          <div className="grid grid-cols-2 gap-4">
            <FormField label="학부모 이름">
              <input
                type="text"
                value={form.parent_name}
                onChange={(e) => set("parent_name", e.target.value)}
                placeholder="홍부모"
                className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </FormField>
            <FormField label="학부모 전화">
              <input
                type="tel"
                value={form.parent_phone}
                onChange={(e) => set("parent_phone", e.target.value)}
                placeholder="010-0000-0000"
                className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </FormField>
          </div>

          <FormField label="학생 전화">
            <input
              type="tel"
              value={form.student_phone}
              onChange={(e) => set("student_phone", e.target.value)}
              placeholder="010-0000-0000"
              className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </FormField>

          <FormField label="메모 (선택)">
            <textarea
              value={form.memo}
              onChange={(e) => set("memo", e.target.value)}
              placeholder="관리 참고사항을 입력하세요"
              rows={3}
              className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            />
          </FormField>
        </div>

        {/* 버튼 */}
        <div className="flex gap-3 px-6 py-4 border-t border-slate-100 justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-lg border border-slate-200 text-slate-600 text-sm font-semibold hover:bg-slate-50 transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white text-sm font-semibold transition-colors"
          >
            {loading ? "처리 중..." : isEdit ? "수정 완료" : "등록하기"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// 삭제 확인 다이얼로그
// ============================================================
function DeleteDialog({ student, onConfirm, onClose, loading }) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl p-6">
        <div className="text-center mb-5">
          <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4">
            <AlertTriangle size={24} className="text-red-500" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 mb-2">
            학생을 삭제할까요?
          </h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            <span className="font-semibold text-slate-700">{student.name}</span>{" "}
            학생의 모든 정보가
            <br />
            영구적으로 삭제됩니다.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-lg border border-slate-200 text-slate-600 text-sm font-semibold hover:bg-slate-50 transition-colors"
          >
            취소
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            className="flex-1 py-2.5 rounded-lg bg-red-500 hover:bg-red-600 disabled:bg-red-300 text-white text-sm font-semibold transition-colors"
          >
            {loading ? "삭제 중..." : "삭제하기"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// 폼 필드 공통 컴포넌트 (라벨 + 입력창 + 에러 메시지)
// ============================================================
function FormField({ label, required, error, children }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-slate-600 mb-1.5">
        {label}
        {required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
}

// ============================================================
// 토스트 알림 컴포넌트 (우측 상단에 잠깐 뜨는 알림)
// ============================================================
function Toast({ msg, type }) {
  const isSuccess = type === "success";
  return (
    <div
      className={`fixed top-5 right-5 z-[100] flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-lg text-white text-sm font-semibold ${
        isSuccess ? "bg-green-500" : "bg-red-500"
      }`}
    >
      <CheckCircle size={16} />
      {msg}
    </div>
  );
}
