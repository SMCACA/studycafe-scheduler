import { Link, useNavigate, useLocation } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'

const menuItems = [
  { label: '대시보드', path: '/dashboard', icon: '📊' },
  { label: '학생 관리', path: '/students', icon: '👨‍🎓' },
  { label: '스케줄 관리', path: '/schedules', icon: '📅' },
  { label: '알림톡 발송', path: '/notifications', icon: '📱' },
]

export default function Layout({ children }) {
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = async () => {
    await supabase.auth.signOut()
    navigate('/login')
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <aside className="w-56 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-5 border-b border-gray-100">
          <p className="text-xs text-gray-400 mb-0.5">관리자 시스템</p>
          <h2 className="font-bold text-blue-700 text-sm">📚 SMC 스터디카페</h2>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition
                ${location.pathname === item.path
                  ? 'bg-blue-50 text-blue-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-100'
                }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t border-gray-100">
          <button
            onClick={handleLogout}
            className="w-full text-left px-3 py-2 text-sm text-gray-400 hover:text-red-500 rounded-lg hover:bg-gray-50 transition"
          >
            🚪 로그아웃
          </button>
        </div>
      </aside>
      <main className="flex-1 overflow-auto p-8">
        {children}
      </main>
    </div>
  )
}