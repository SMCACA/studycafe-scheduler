import Layout from '../components/Layout'

export default function Dashboard() {
  return (
    <Layout>
      <h1 className="text-2xl font-bold text-gray-800 mb-2">대시보드</h1>
      <p className="text-gray-400 text-sm">2단계에서 학생 현황을 여기 채울 예정입니다.</p>

      <div className="mt-8 grid grid-cols-3 gap-4">
        {['전체 학생', '이번 주 알림톡', '등록 스케줄'].map((label) => (
          <div key={label} className="bg-white rounded-xl border border-gray-200 p-5">
            <p className="text-sm text-gray-400">{label}</p>
            <p className="text-3xl font-bold text-gray-700 mt-1">0</p>
          </div>
        ))}
      </div>
    </Layout>
  )
}