import { useState, useEffect, useMemo } from 'react'
import { Users, Search, Plus, Edit2, Trash2, X, CheckCircle, AlertTriangle, ChevronUp, ChevronDown, Armchair, Settings2, Check } from 'lucide-react'
import { createClient } from '@supabase/supabase-js'
import Layout from '../components/Layout'
import { fetchSeatConfig, updateSeatConfig } from '../lib/seatConfig'

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
)

const GRADES = ['중1','중2','중3','고1','고2','고3','성인']

// ✅ 학생 상태 정의
const STATUS_OPTIONS = ['재원생', '예비원생', '퇴원생']
// ⚠️ [2026-06-23 수정] 퇴원생 색상 버그 수정
//    예전 값은 bg:'#F8FAFC', color:'#94A3B8', border:'#E2E8F0' 였는데,
//    이게 버튼이 "선택 안 됐을 때(비활성)" 기본 색깔과 똑같았어요.
//    그래서 퇴원생을 클릭해서 선택해도 안 누른 것처럼 보였던 거예요.
//    (비유: 도장 색깔을 종이 색깔과 똑같이 만들어서, 도장을 찍어도 안 보이는 상황)
//    이제 다른 상태들처럼 또렷하게 구분되는 색(붉은 계열)으로 바꿨어요.
const STATUS_STYLE = {
  재원생:  { bg:'#ECFDF5', color:'#059669', border:'#A7F3D0' },
  예비원생: { bg:'#EEF2FF', color:'#6366F1', border:'#C7D2FE' },
  퇴원생:  { bg:'#FEF2F2', color:'#DC2626', border:'#FCA5A5' },
}

// ✅ [신규] SMC 재원생(학원 수강 여부) 구분 — 스터디카페 재원 상태(STATUS_OPTIONS)와는 별개예요
//    true  = SMC 재원생 (학원 수업도 같이 듣는 학생)
//    false = 비재원생   (스터디카페만 이용하는 학생)
const ACADEMY_OPTIONS = [
  { value: true,  label: 'SMC 재원생' },
  { value: false, label: '비재원생' },
]
const ACADEMY_STYLE = {
  true:  { bg:'#FFFBEB', color:'#D97706', border:'#FDE68A' },
  false: { bg:'#F1F5F9', color:'#64748B', border:'#E2E8F0' },
}

const cell = { border:'1px solid #E2E8F0', padding:'11px 14px', verticalAlign:'middle' }

export default function StudentManagement() {
  const [students,       setStudents]       = useState([])
  const [search,         setSearch]         = useState('')
  const [statusFilter,   setStatusFilter]   = useState('재원생')   // ✅ 상태 필터 (기본: 재원생)
  const [isModalOpen,    setIsModalOpen]    = useState(false)
  const [editingStudent, setEditingStudent] = useState(null)
  const [deleteTarget,   setDeleteTarget]   = useState(null)
  const [toast,          setToast]          = useState(null)
  const [loading,        setLoading]        = useState(false)
  // ✅ 정렬 상태 (좌석 정렬 기능)
  const [sortField,      setSortField]      = useState('name')
  const [sortDir,        setSortDir]        = useState('asc')

  // ✅ [신규] 좌석번호 사용 범위 (예: 1~30)
  const [seatConfig,     setSeatConfig]     = useState({ min_seat: 1, max_seat: 30 })
  const [editingRange,   setEditingRange]   = useState(false)
  const [rangeForm,      setRangeForm]      = useState({ min: '1', max: '30' })
  const [savingRange,    setSavingRange]    = useState(false)

  useEffect(() => { fetchStudents(); loadSeatConfig() }, [])

  const loadSeatConfig = async () => {
    const cfg = await fetchSeatConfig()
    setSeatConfig(cfg)
    setRangeForm({ min: String(cfg.min_seat), max: String(cfg.max_seat) })
  }

  const handleSaveRange = async () => {
    const min = Number(rangeForm.min)
    const max = Number(rangeForm.max)
    if (!min || !max || min < 1 || max < min) {
      showToast('좌석 범위를 올바르게 입력해주세요 (예: 1 ~ 30)', 'error')
      return
    }
    setSavingRange(true)
    try {
      const updated = await updateSeatConfig({ minSeat: min, maxSeat: max })
      setSeatConfig(updated)
      setEditingRange(false)
      showToast(`좌석 사용 범위가 ${min}번 ~ ${max}번으로 설정됐어요 🪑`)
    } catch (err) {
      showToast('좌석 범위 저장 실패: ' + err.message, 'error')
    }
    setSavingRange(false)
  }

  // ✅ [신규] 현재 배정된 좌석번호 집합 (재원생 + 예비원생 모두 포함, 퇴원생은 제외)
  //    퇴원생은 좌석을 더 이상 쓰지 않으니 그 번호는 "미배정"으로 다시 보여줘요.
  const occupiedSeats = useMemo(() => {
    const set = new Set()
    students.forEach(s => {
      const st = s.status || '재원생'
      if ((st === '재원생' || st === '예비원생') && s.seat_number != null) {
        set.add(Number(s.seat_number))
      }
    })
    return set
  }, [students])

  // ✅ [신규] 설정된 범위 안에서 아직 아무도 배정되지 않은 좌석번호 목록
  const unassignedSeats = useMemo(() => {
    const list = []
    for (let n = seatConfig.min_seat; n <= seatConfig.max_seat; n++) {
      if (!occupiedSeats.has(n)) list.push(n)
    }
    return list
  }, [seatConfig, occupiedSeats])

  const fetchStudents = async () => {
    const { data, error } = await supabase.from('students').select('*').order('name')
    if (error) { showToast('학생 목록을 불러오지 못했어요', 'error'); return }
    setStudents(data || [])
  }

  // ✅ 상태 필터 + 검색 필터 동시 적용
  const filtered = students.filter(s => {
    const matchStatus = statusFilter === '전체' || (s.status || '재원생') === statusFilter
    const matchSearch = !search ||
      s.name?.includes(search) || s.school?.includes(search) ||
      s.grade?.includes(search) || String(s.seat_number||'').includes(search)
    return matchStatus && matchSearch
  })

  // ✅ 정렬 적용 (좌석, 이름 정렬)
  const sorted = [...filtered].sort((a, b) => {
    let valA, valB
    if (sortField === 'seat') {
      valA = a.seat_number ?? 9999
      valB = b.seat_number ?? 9999
      return sortDir === 'asc' ? valA - valB : valB - valA
    }
    // 기본: 이름순
    valA = a.name || ''
    valB = b.name || ''
    return sortDir === 'asc'
      ? valA.localeCompare(valB, 'ko')
      : valB.localeCompare(valA, 'ko')
  })

  // ✅ 정렬 토글 함수
  const toggleSort = (field) => {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    else { setSortField(field); setSortDir('asc') }
  }

  const showToast = (msg, type='success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 2500)
  }

  const openAdd  = () => { setEditingStudent(null); setIsModalOpen(true) }
  const openEdit = s  => { setEditingStudent(s);    setIsModalOpen(true) }
  const closeModal = () => { setIsModalOpen(false); setEditingStudent(null) }

  const handleSave = async (formData) => {
    setLoading(true)
    try {
      if (editingStudent) {
        const { error } = await supabase.from('students').update(formData).eq('id', editingStudent.id)
        if (error) throw error
        showToast(`${formData.name} 학생 정보가 수정됐어요 ✏️`)
      } else {
        const { error } = await supabase.from('students').insert(formData)
        if (error) throw error
        showToast(`${formData.name} 학생이 등록됐어요 🎉`)
      }
      closeModal(); fetchStudents()
    } catch (err) { showToast(`저장 실패: ${err.message}`, 'error') }
    finally { setLoading(false) }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setLoading(true)
    try {
      const { error } = await supabase.from('students').delete().eq('id', deleteTarget.id)
      if (error) throw error
      showToast(`${deleteTarget.name} 학생이 삭제됐어요 🗑️`, 'error')
      setDeleteTarget(null); fetchStudents()
    } catch (err) { showToast(`삭제 실패: ${err.message}`, 'error') }
    finally { setLoading(false) }
  }

  // 각 상태별 인원수
  const countByStatus = (status) => students.filter(s => (s.status || '재원생') === status).length

  return (
    <Layout>
      {toast && <Toast msg={toast.msg} type={toast.type} />}

      <div style={{ padding:'28px 32px' }}>

        {/* ── 페이지 헤더 ── */}
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', marginBottom:'20px' }}>
          <div style={{ display:'flex', alignItems:'center', gap:'14px' }}>
            <div style={{ width:'46px', height:'46px', borderRadius:'14px', background:'#EEF2FF', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <Users size={22} style={{ color:'#6366F1' }} />
            </div>
            <div>
              <h1 style={{ fontSize:'22px', fontWeight:700, color:'#0F172A', margin:0 }}>학생 관리</h1>
              <p style={{ fontSize:'13px', color:'#94A3B8', marginTop:'3px' }}>
                재원생 {countByStatus('재원생')}명 · 예비원생 {countByStatus('예비원생')}명 · 퇴원생 {countByStatus('퇴원생')}명
              </p>
            </div>
          </div>
          <button
            onClick={openAdd}
            style={{
              display:'flex', alignItems:'center', gap:'8px',
              padding:'11px 20px', borderRadius:'12px', border:'none',
              background:'linear-gradient(135deg,#6366F1,#7C3AED)',
              color:'#fff', fontSize:'14px', fontWeight:700, cursor:'pointer',
              boxShadow:'0 4px 12px rgba(99,102,241,0.3)',
            }}
            onMouseEnter={e => { e.currentTarget.style.transform='translateY(-1px)'; e.currentTarget.style.boxShadow='0 6px 16px rgba(99,102,241,0.4)' }}
            onMouseLeave={e => { e.currentTarget.style.transform='translateY(0)'; e.currentTarget.style.boxShadow='0 4px 12px rgba(99,102,241,0.3)' }}
          >
            <Plus size={16} /> 학생 등록
          </button>
        </div>

        {/* ✅ [신규] 좌석 설정 + 미배정 좌석 표시 패널 */}
        <div style={{
          background: '#fff', borderRadius: '16px', border: '1px solid #E2E8F0',
          padding: '18px 22px', marginBottom: '20px', boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px', flexWrap: 'wrap', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Armchair size={16} style={{ color: '#6366F1' }} />
              <span style={{ fontSize: '13px', fontWeight: 700, color: '#374151' }}>좌석 사용 범위</span>
              {!editingRange && (
                <span style={{ fontSize: '13px', color: '#6366F1', fontWeight: 700 }}>
                  {seatConfig.min_seat}번 ~ {seatConfig.max_seat}번
                </span>
              )}
            </div>

            {editingRange ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <input type="number" min="1" value={rangeForm.min}
                  onChange={e => setRangeForm(f => ({ ...f, min: e.target.value }))}
                  style={{ width: '64px', padding: '6px 8px', borderRadius: '8px', border: '1.5px solid #C7D2FE', fontSize: '12px', textAlign: 'center' }} />
                <span style={{ color: '#94A3B8', fontSize: '12px' }}>~</span>
                <input type="number" min="1" value={rangeForm.max}
                  onChange={e => setRangeForm(f => ({ ...f, max: e.target.value }))}
                  style={{ width: '64px', padding: '6px 8px', borderRadius: '8px', border: '1.5px solid #C7D2FE', fontSize: '12px', textAlign: 'center' }} />
                <button onClick={handleSaveRange} disabled={savingRange} style={{
                  display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 12px', borderRadius: '8px',
                  border: 'none', background: '#6366F1', color: '#fff', fontSize: '12px', fontWeight: 700, cursor: 'pointer',
                }}><Check size={12} /> {savingRange ? '저장 중...' : '저장'}</button>
                <button onClick={() => { setEditingRange(false); setRangeForm({ min: String(seatConfig.min_seat), max: String(seatConfig.max_seat) }) }} style={{
                  padding: '6px 10px', borderRadius: '8px', border: '1.5px solid #E2E8F0', background: '#fff',
                  color: '#94A3B8', fontSize: '12px', cursor: 'pointer',
                }}>취소</button>
              </div>
            ) : (
              <button onClick={() => setEditingRange(true)} style={{
                display: 'flex', alignItems: 'center', gap: '5px', padding: '6px 12px', borderRadius: '8px',
                border: '1px solid #E2E8F0', background: '#F8FAFC', color: '#64748B', fontSize: '12px', fontWeight: 600, cursor: 'pointer',
              }}><Settings2 size={12} /> 범위 수정</button>
            )}
          </div>

          <p style={{ fontSize: '11px', color: '#94A3B8', marginBottom: '8px' }}>
            미배정 좌석 {unassignedSeats.length}개 (재원생·예비원생 기준, 학생 등록 시 이 안에서 선택할 수 있어요)
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', maxHeight: '88px', overflowY: 'auto' }}>
            {unassignedSeats.length === 0 ? (
              <span style={{ fontSize: '12px', color: '#CBD5E1' }}>모든 좌석이 배정됐어요 🎉</span>
            ) : (
              unassignedSeats.map(n => (
                <span key={n} style={{
                  display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                  width: '30px', height: '28px', borderRadius: '8px',
                  background: '#ECFDF5', color: '#059669', border: '1px solid #A7F3D0',
                  fontSize: '12px', fontWeight: 700,
                }}>{n}</span>
              ))
            )}
          </div>
        </div>

        {/* ✅ 상태 필터 탭 */}
        <div style={{ display:'flex', gap:'8px', marginBottom:'16px', flexWrap:'wrap' }}>
          {['전체', ...STATUS_OPTIONS].map(st => {
            const count = st === '전체' ? students.length : countByStatus(st)
            const isActive = statusFilter === st
            const sty = STATUS_STYLE[st] || { bg:'#F1F5F9', color:'#475569', border:'#E2E8F0' }
            return (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                style={{
                  display:'flex', alignItems:'center', gap:'6px',
                  padding:'7px 16px', borderRadius:'999px', fontSize:'13px', fontWeight:600,
                  cursor:'pointer', transition:'all 0.15s',
                  border: isActive ? `1.5px solid ${sty.border}` : '1.5px solid #E2E8F0',
                  background: isActive ? sty.bg : '#fff',
                  color: isActive ? sty.color : '#64748B',
                  boxShadow: isActive ? `0 0 0 3px ${sty.border}44` : 'none',
                }}
              >
                {st}
                <span style={{
                  display:'inline-flex', alignItems:'center', justifyContent:'center',
                  width:'18px', height:'18px', borderRadius:'999px', fontSize:'10px', fontWeight:700,
                  background: isActive ? sty.color : '#E2E8F0',
                  color: isActive ? '#fff' : '#64748B',
                }}>{count}</span>
              </button>
            )
          })}

          {/* 검색창 (오른쪽) */}
          <div style={{ position:'relative', marginLeft:'auto' }}>
            <Search size={15} style={{ position:'absolute', left:'14px', top:'50%', transform:'translateY(-50%)', color:'#CBD5E1' }} />
            <input
              type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="이름, 학교, 학년, 좌석번호 검색"
              style={{
                padding:'9px 14px 9px 40px', borderRadius:'12px',
                border:'1.5px solid #E2E8F0', fontSize:'13px', outline:'none',
                background:'#fff', color:'#0F172A', width:'240px',
              }}
              onFocus={e => { e.target.style.borderColor='#6366F1'; e.target.style.boxShadow='0 0 0 3px rgba(99,102,241,0.1)' }}
              onBlur={e  => { e.target.style.borderColor='#E2E8F0'; e.target.style.boxShadow='none' }}
            />
          </div>
        </div>

        {/* ── 학생 테이블 ── */}
        <div style={{
          background:'#fff', borderRadius:'16px',
          border:'1px solid #E2E8F0', overflowX:'auto',
          boxShadow:'0 1px 4px rgba(0,0,0,0.04)',
        }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:'13px' }}>
            <thead>
              <tr>
                {/* ✅ 좌석 - 정렬 가능 */}
                <th
                  onClick={() => toggleSort('seat')}
                  style={{
                    ...cell, background:'#F8FAFC',
                    fontSize:'11px', fontWeight:700, color: sortField==='seat' ? '#6366F1' : '#64748B',
                    letterSpacing:'0.04em', textAlign:'left', whiteSpace:'nowrap',
                    cursor:'pointer', userSelect:'none',
                  }}
                >
                  <span style={{ display:'inline-flex', alignItems:'center', gap:'4px' }}>
                    좌석
                    {sortField === 'seat'
                      ? (sortDir === 'asc' ? <ChevronUp size={12} style={{ color:'#6366F1' }} /> : <ChevronDown size={12} style={{ color:'#6366F1' }} />)
                      : <span style={{ color:'#CBD5E1', fontSize:'10px' }}>↕</span>
                    }
                  </span>
                </th>
                {/* ✅ 이름 - 정렬 가능 */}
                <th
                  onClick={() => toggleSort('name')}
                  style={{
                    ...cell, background:'#F8FAFC',
                    fontSize:'11px', fontWeight:700, color: sortField==='name' ? '#6366F1' : '#64748B',
                    letterSpacing:'0.04em', textAlign:'left', whiteSpace:'nowrap',
                    cursor:'pointer', userSelect:'none',
                  }}
                >
                  <span style={{ display:'inline-flex', alignItems:'center', gap:'4px' }}>
                    이름
                    {sortField === 'name'
                      ? (sortDir === 'asc' ? <ChevronUp size={12} style={{ color:'#6366F1' }} /> : <ChevronDown size={12} style={{ color:'#6366F1' }} />)
                      : <span style={{ color:'#CBD5E1', fontSize:'10px' }}>↕</span>
                    }
                  </span>
                </th>
                {['상태','SMC','학년','학교','학부모 전화','학생 전화','첫등원일','질문방','특이사항','메모','관리'].map(h => (
                  <th key={h} style={{
                    ...cell, background:'#F8FAFC',
                    fontSize:'11px', fontWeight:700, color:'#64748B',
                    letterSpacing:'0.04em', textAlign:'left', whiteSpace:'nowrap',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.length === 0 ? (
                <tr>
                  <td colSpan={13} style={{ ...cell, textAlign:'center', padding:'64px 0' }}>
                    <Users size={32} style={{ color:'#E2E8F0', display:'block', margin:'0 auto 10px' }} />
                    <p style={{ color:'#94A3B8', fontSize:'14px' }}>
                      {search ? '검색 결과가 없어요' : `${statusFilter} 학생이 없어요`}
                    </p>
                  </td>
                </tr>
              ) : (
                sorted.map((s, idx) => {
                  const isHigh = s.grade?.startsWith('고')
                  const status = s.status || '재원생'
                  const sStyle = STATUS_STYLE[status]
                  return (
                    <tr key={s.id}
                      style={{ background: idx%2===0 ? '#fff' : '#FAFBFF', transition:'background 0.12s' }}
                      onMouseEnter={e => { e.currentTarget.style.background='#F0F4FF' }}
                      onMouseLeave={e => { e.currentTarget.style.background = idx%2===0 ? '#fff' : '#FAFBFF' }}
                    >
                      {/* 좌석 */}
                      <td style={{ ...cell, textAlign:'center' }}>
                        {s.seat_number
                          ? <span style={{ display:'inline-flex', alignItems:'center', justifyContent:'center', width:'28px', height:'28px', borderRadius:'8px', background:'#EEF2FF', color:'#6366F1', fontSize:'12px', fontWeight:700 }}>{s.seat_number}</span>
                          : <span style={{ color:'#CBD5E1' }}>–</span>
                        }
                      </td>
                      {/* 이름 */}
                      <td style={{ ...cell, fontWeight:700, color:'#0F172A', whiteSpace:'nowrap' }}>{s.name}</td>
                      {/* ✅ 상태 배지 */}
                      <td style={cell}>
                        <span style={{
                          padding:'2px 10px', borderRadius:'999px', fontSize:'11px', fontWeight:700,
                          background: sStyle.bg, color: sStyle.color, border: `1px solid ${sStyle.border}`,
                          whiteSpace:'nowrap',
                        }}>{status}</span>
                      </td>
                      {/* ✅ [신규] SMC 재원생 배지 (재원 상태와는 별개) */}
                      <td style={cell}>
                        {(() => {
                          const aSty = ACADEMY_STYLE[!!s.is_academy_student]
                          return (
                            <span style={{
                              padding:'2px 10px', borderRadius:'999px', fontSize:'11px', fontWeight:700,
                              background: aSty.bg, color: aSty.color, border: `1px solid ${aSty.border}`,
                              whiteSpace:'nowrap',
                            }}>{s.is_academy_student ? 'SMC 재원생' : '비재원생'}</span>
                          )
                        })()}
                      </td>
                      {/* 학년 */}
                      <td style={cell}>
                        {s.grade && (
                          <span style={{
                            padding:'2px 10px', borderRadius:'999px', fontSize:'11px', fontWeight:700,
                            background: isHigh ? '#EEF2FF' : '#ECFDF5',
                            color:      isHigh ? '#4F46E5' : '#059669',
                          }}>{s.grade}</span>
                        )}
                      </td>
                      {/* 학교 */}
                      <td style={{ ...cell, color:'#64748B' }}>{s.school || '–'}</td>
                      {/* 학부모 전화 */}
                      <td style={{ ...cell, color:'#64748B', fontFamily:'monospace', fontSize:'12px' }}>{s.parent_phone || '–'}</td>
                      {/* 학생 전화 */}
                      <td style={{ ...cell, color:'#64748B', fontFamily:'monospace', fontSize:'12px' }}>{s.student_phone || '–'}</td>
                      {/* ✅ 첫등원일 */}
                      <td style={{ ...cell, color:'#64748B', fontSize:'12px', whiteSpace:'nowrap' }}>
                        {s.first_attendance_date
                          ? <span style={{ padding:'2px 8px', borderRadius:'999px', fontSize:'11px', fontWeight:600, background:'#EEF2FF', color:'#4F46E5' }}>
                              {s.first_attendance_date}
                            </span>
                          : <span style={{ color:'#CBD5E1' }}>–</span>
                        }
                      </td>
                      {/* ✅ [신규] 질문방 참여 여부 */}
                      <td style={{ ...cell, textAlign:'center' }}>
                        {s.is_question_room_member
                          ? <span style={{
                              display:'inline-flex', alignItems:'center', gap:'4px',
                              padding:'2px 8px', borderRadius:'999px', fontSize:'11px', fontWeight:700,
                              background:'#ECFDF5', color:'#059669', border:'1px solid #A7F3D0',
                            }}>✅ 참여</span>
                          : <span style={{ color:'#CBD5E1' }}>–</span>
                        }
                      </td>
                      {/* ✅ 특이사항 */}
                      <td style={{ ...cell, textAlign:'center' }}>
                        {s.special_notes
                          ? <span title={s.special_notes} style={{
                              display:'inline-flex', alignItems:'center', gap:'4px',
                              padding:'2px 8px', borderRadius:'999px', fontSize:'11px', fontWeight:700,
                              background:'#FFF7ED', color:'#D97706', border:'1px solid #FDE68A', cursor:'help',
                            }}>⚠️ 있음</span>
                          : <span style={{ color:'#CBD5E1' }}>–</span>
                        }
                      </td>
                      {/* 메모 */}
                      <td style={{ ...cell, color:'#CBD5E1', maxWidth:'120px' }}>
                        <span style={{ display:'block', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                          {s.memo || '–'}
                        </span>
                      </td>
                      {/* 관리 버튼 */}
                      <td style={cell}>
                        <div style={{ display:'flex', gap:'6px' }}>
                          <button onClick={() => openEdit(s)} style={{ display:'flex', alignItems:'center', gap:'4px', padding:'5px 10px', borderRadius:'8px', fontSize:'11px', fontWeight:700, background:'#EEF2FF', color:'#6366F1', border:'1px solid #C7D2FE', cursor:'pointer' }}
                            onMouseEnter={e => { e.currentTarget.style.background='#E0E7FF' }}
                            onMouseLeave={e => { e.currentTarget.style.background='#EEF2FF' }}>
                            <Edit2 size={11} /> 수정
                          </button>
                          <button onClick={() => setDeleteTarget(s)} style={{ display:'flex', alignItems:'center', gap:'4px', padding:'5px 10px', borderRadius:'8px', fontSize:'11px', fontWeight:700, background:'#FEF2F2', color:'#EF4444', border:'1px solid #FECACA', cursor:'pointer' }}
                            onMouseEnter={e => { e.currentTarget.style.background='#FEE2E2' }}
                            onMouseLeave={e => { e.currentTarget.style.background='#FEF2F2' }}>
                            <Trash2 size={11} /> 삭제
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <StudentModal student={editingStudent} onSave={handleSave} onClose={closeModal} loading={loading}
          availableSeats={unassignedSeats} />
      )}
      {deleteTarget && (
        <DeleteDialog student={deleteTarget} onConfirm={handleDelete} onClose={() => setDeleteTarget(null)} loading={loading} />
      )}
    </Layout>
  )
}

// ── 등록/수정 모달 ──────────────────────────────────────
function StudentModal({ student, onSave, onClose, loading, availableSeats = [] }) {
  const isEdit = !!student

  // ✅ [신규] 드롭다운에 보여줄 좌석번호 목록
  //    "현재 비어있는 좌석" + "이 학생이 지금 쓰고 있는 좌석(수정 모드일 때)"을 합쳐서
  //    숫자 순서로 정렬해요. (자기 자신의 좌석은 당연히 선택할 수 있어야 하니까요!)
  const selectableSeats = useMemo(() => {
    const set = new Set(availableSeats)
    if (student?.seat_number != null) set.add(Number(student.seat_number))
    return [...set].sort((a, b) => a - b)
  }, [availableSeats, student])

  const [form, setForm] = useState({
    name:          student?.name          || '',
    grade:         student?.grade         || '',
    school:        student?.school        || '',
    seat_number:   student?.seat_number   || '',
    parent_phone:  student?.parent_phone  || '',
    student_phone: student?.student_phone || '',
    status:        student?.status        || '재원생',  // ✅ 추가
    is_academy_student: student?.is_academy_student ?? false, // ✅ SMC 재원생(학원 수강생) 여부 — 스터디카페 상태와는 별개
    is_question_room_member: student?.is_question_room_member ?? false, // ✅ [신규] 질문방 참여 여부 (체크만, 들어갔는지/안갔는지만 확인)
    special_notes: student?.special_notes || '',        // ✅ 추가
    memo:          student?.memo          || '',
    first_attendance_date: student?.first_attendance_date || '',  // ✅ 첫등원일자
  })
  const [errors, setErrors] = useState({})

  const set = (key, value) => {
    setForm(f => ({ ...f, [key]: value }))
    if (errors[key]) setErrors(e => ({ ...e, [key]: '' }))
  }

  const validate = () => {
    const e = {}
    if (!form.name.trim()) e.name = '이름을 입력해주세요'
    if (!form.grade)        e.grade = '학년을 선택해주세요'
    if (form.seat_number !== '' && isNaN(Number(form.seat_number)))
      e.seat_number = '숫자만 입력해주세요'
    return e
  }

  const handleSubmit = () => {
    const e = validate()
    if (Object.keys(e).length > 0) { setErrors(e); return }
    onSave({ ...form, seat_number: form.seat_number !== '' ? Number(form.seat_number) : null })
  }

  const inputStyle = (hasError) => ({
    width:'100%', padding:'9px 12px', borderRadius:'10px',
    border:`1.5px solid ${hasError ? '#FCA5A5' : '#E2E8F0'}`,
    background: hasError ? '#FEF2F2' : '#F8FAFC',
    fontSize:'13px', outline:'none', color:'#0F172A', boxSizing:'border-box',
  })

  const focusStyle = { borderColor:'#6366F1', boxShadow:'0 0 0 3px rgba(99,102,241,0.1)' }
  const blurStyle  = (err) => ({ borderColor: err ? '#FCA5A5' : '#E2E8F0', boxShadow:'none' })

  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(15,23,42,0.55)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:50, padding:'16px' }}>
      <div style={{ background:'#fff', borderRadius:'24px', width:'100%', maxWidth:'540px', maxHeight:'92vh', overflowY:'auto', boxShadow:'0 20px 60px rgba(0,0,0,0.15)' }}>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'20px 24px 16px', borderBottom:'1px solid #F1F5F9' }}>
          <h2 style={{ fontSize:'17px', fontWeight:700, color:'#0F172A', margin:0 }}>
            {isEdit ? '학생 정보 수정' : '새 학생 등록'}
          </h2>
          <button onClick={onClose} style={{ width:'32px', height:'32px', borderRadius:'10px', border:'none', background:'#F1F5F9', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <X size={16} style={{ color:'#64748B' }} />
          </button>
        </div>

        <div style={{ padding:'20px 24px', display:'flex', flexDirection:'column', gap:'14px' }}>
          {/* 이름 + 학년 */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
            <Field label="이름" required error={errors.name}>
              <input type="text" value={form.name} onChange={e=>set('name',e.target.value)} placeholder="홍길동"
                style={inputStyle(!!errors.name)}
                onFocus={e=>Object.assign(e.target.style,focusStyle)}
                onBlur={e=>Object.assign(e.target.style,blurStyle(errors.name))} />
            </Field>
            <Field label="학년" required error={errors.grade}>
              <select value={form.grade} onChange={e=>set('grade',e.target.value)}
                style={{ ...inputStyle(!!errors.grade), appearance:'none', cursor:'pointer' }}
                onFocus={e=>Object.assign(e.target.style,focusStyle)}
                onBlur={e=>Object.assign(e.target.style,blurStyle(errors.grade))}>
                <option value="">학년 선택</option>
                {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </Field>
          </div>

          {/* ✅ 재원 상태 (스터디카페 등록 상태 — 재원생/예비원생/퇴원생) */}
          <Field label="재원 상태">
            <div style={{ display:'flex', gap:'8px' }}>
              {STATUS_OPTIONS.map(st => {
                const sty = STATUS_STYLE[st]
                const isActive = form.status === st
                return (
                  <button key={st} type="button" onClick={() => set('status', st)}
                    style={{
                      flex:1, padding:'8px', borderRadius:'10px', fontSize:'13px', fontWeight:600,
                      cursor:'pointer', transition:'all 0.15s',
                      border: isActive ? `2px solid ${sty.border}` : '2px solid #E2E8F0',
                      background: isActive ? sty.bg : '#F8FAFC',
                      color: isActive ? sty.color : '#94A3B8',
                    }}>
                    {st}
                  </button>
                )
              })}
            </div>
          </Field>

          {/* ✅ [신규] SMC 재원생 구분 — "스터디카페 재원 상태"와는 완전히 별개의 구분이에요.
                비유: 재원 상태는 "이 카페에 다니는지"이고, 이 항목은 "SMC 학원(수업)도 같이 다니는지"예요.
                두 학생이 똘다 재원생이어도, 한 명은 SMC 학원도 다니고(SMC 재원생),
                한 명은 스터디카페만 이용(비재원생)할 수 있어요. */}
          <Field label="SMC 재원생 구분 (학원 수강 여부 — 재원 상태와는 별개예요)">
            <div style={{ display:'flex', gap:'8px' }}>
              {ACADEMY_OPTIONS.map(opt => {
                const sty = ACADEMY_STYLE[opt.value]
                const isActive = form.is_academy_student === opt.value
                return (
                  <button key={String(opt.value)} type="button" onClick={() => set('is_academy_student', opt.value)}
                    style={{
                      flex:1, padding:'8px', borderRadius:'10px', fontSize:'13px', fontWeight:600,
                      cursor:'pointer', transition:'all 0.15s',
                      border: isActive ? `2px solid ${sty.border}` : '2px solid #E2E8F0',
                      background: isActive ? sty.bg : '#F8FAFC',
                      color: isActive ? sty.color : '#94A3B8',
                    }}>
                    {opt.label}
                  </button>
                )
              })}
            </div>
          </Field>

          {/* ✅ [신규] 질문방 참여 여부 — 단순히 "참여했는지 / 안 했는지"만 체크해서 확인하는 항목이에요 */}
          <Field label="질문방 참여">
            <label style={{
              display:'flex', alignItems:'center', gap:'10px', cursor:'pointer',
              padding:'10px 12px', borderRadius:'10px',
              border: form.is_question_room_member ? '1.5px solid #A7F3D0' : '1.5px solid #E2E8F0',
              background: form.is_question_room_member ? '#ECFDF5' : '#F8FAFC',
              transition:'all 0.15s', width:'fit-content',
            }}>
              <input
                type="checkbox"
                checked={form.is_question_room_member}
                onChange={e => set('is_question_room_member', e.target.checked)}
                style={{ width:'16px', height:'16px', cursor:'pointer', accentColor:'#059669' }}
              />
              <span style={{ fontSize:'13px', fontWeight:600, color: form.is_question_room_member ? '#059669' : '#64748B' }}>
                질문방에 참여했어요
              </span>
            </label>
          </Field>

          {/* 학교 + 좌석 */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px' }}>
            <Field label="학교">
              <input type="text" value={form.school} onChange={e=>set('school',e.target.value)} placeholder="한빛고등학교"
                style={inputStyle(false)}
                onFocus={e=>Object.assign(e.target.style,focusStyle)}
                onBlur={e=>Object.assign(e.target.style,blurStyle(false))} />
            </Field>
            <Field label="좌석번호" error={errors.seat_number}>
              <select value={form.seat_number} onChange={e => set('seat_number', e.target.value)}
                style={inputStyle(!!errors.seat_number)}
                onFocus={e=>Object.assign(e.target.style,focusStyle)}
                onBlur={e=>Object.assign(e.target.style,blurStyle(errors.seat_number))}>
                <option value="">선택 안 함</option>
                {selectableSeats.map(n => (
                  <option key={n} value={n}>
                    {n}번{student?.seat_number === n ? ' (현재 좌석)' : ''}
                  </option>
                ))}
              </select>
              <p style={{ fontSize: '11px', color: '#94A3B8', marginTop: '4px' }}>
                💡 비어있는 좌석만 골라서 배정할 수 있어요 (범위는 학생 관리 화면 상단에서 설정)
              </p>
            </Field>
          </div>

          {/* 학부모 전화 (학부모 이름은 등록 항목에서 제외했어요) */}
          <Field label="학부모 전화">
            <input type="tel" value={form.parent_phone} onChange={e=>set('parent_phone',e.target.value)} placeholder="010-0000-0000"
              style={inputStyle(false)}
              onFocus={e=>Object.assign(e.target.style,focusStyle)}
              onBlur={e=>Object.assign(e.target.style,blurStyle(false))} />
          </Field>

          <Field label="학생 전화">
            <input type="tel" value={form.student_phone} onChange={e=>set('student_phone',e.target.value)} placeholder="010-0000-0000"
              style={inputStyle(false)}
              onFocus={e=>Object.assign(e.target.style,focusStyle)}
              onBlur={e=>Object.assign(e.target.style,blurStyle(false))} />
          </Field>

          {/* ✅ 첫등원일자 - 이 날짜 이전은 등원기록에 표시 안 됨 */}
          <Field label="📅 첫등원일자 (이 날짜 이전은 등원기록에 미표시)">
            <input
              type="date"
              value={form.first_attendance_date}
              onChange={e => set('first_attendance_date', e.target.value)}
              style={{
                ...inputStyle(false),
                border: '1.5px solid #C7D2FE', background: '#EEF2FF', color: '#4F46E5',
              }}
              onFocus={e => { e.target.style.borderColor='#6366F1'; e.target.style.boxShadow='0 0 0 3px rgba(99,102,241,0.1)' }}
              onBlur={e  => { e.target.style.borderColor='#C7D2FE'; e.target.style.boxShadow='none' }}
            />
            <p style={{ fontSize:'11px', color:'#94A3B8', marginTop:'4px' }}>
              💡 비워두면 스케줄 등록 시점부터 모든 날짜에 등원기록이 표시돼요
            </p>
          </Field>

          {/* ✅ 특이사항 */}
          <Field label="⚠️ 특이사항 (등원기록에 표시됨)">
            <textarea value={form.special_notes} onChange={e=>set('special_notes',e.target.value)}
              placeholder="알레르기, 건강 주의사항, 보호자 요청사항 등"
              rows={3}
              style={{ ...inputStyle(false), resize:'none', fontFamily:'inherit', border:'1.5px solid #FDE68A', background:'#FFFBEB' }}
              onFocus={e=>{ e.target.style.borderColor='#F59E0B'; e.target.style.boxShadow='0 0 0 3px rgba(245,158,11,0.1)' }}
              onBlur={e=>{ e.target.style.borderColor='#FDE68A'; e.target.style.boxShadow='none' }} />
          </Field>

          <Field label="메모 (내부용)">
            <textarea value={form.memo} onChange={e=>set('memo',e.target.value)} placeholder="관리 참고사항을 입력하세요" rows={2}
              style={{ ...inputStyle(false), resize:'none', fontFamily:'inherit' }}
              onFocus={e=>Object.assign(e.target.style,focusStyle)}
              onBlur={e=>Object.assign(e.target.style,blurStyle(false))} />
          </Field>
        </div>

        <div style={{ display:'flex', gap:'10px', padding:'16px 24px', borderTop:'1px solid #F1F5F9' }}>
          <button onClick={onClose} style={{ flex:1, padding:'12px', borderRadius:'12px', border:'1.5px solid #E2E8F0', background:'#fff', fontSize:'14px', fontWeight:600, color:'#64748B', cursor:'pointer' }}>
            취소
          </button>
          <button onClick={handleSubmit} disabled={loading} style={{
            flex:1, padding:'12px', borderRadius:'12px', border:'none',
            background: loading ? '#A5B4FC' : 'linear-gradient(135deg,#6366F1,#7C3AED)',
            fontSize:'14px', fontWeight:700, color:'#fff', cursor: loading ? 'not-allowed' : 'pointer',
            boxShadow: loading ? 'none' : '0 4px 14px rgba(99,102,241,0.35)',
          }}>
            {loading ? '처리 중…' : isEdit ? '수정 완료' : '등록하기'}
          </button>
        </div>
      </div>
    </div>
  )
}

function DeleteDialog({ student, onConfirm, onClose, loading }) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(15,23,42,0.55)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:50, padding:'16px' }}>
      <div style={{ background:'#fff', borderRadius:'24px', width:'100%', maxWidth:'360px', padding:'28px 24px', boxShadow:'0 20px 60px rgba(0,0,0,0.15)' }}>
        <div style={{ textAlign:'center', marginBottom:'24px' }}>
          <div style={{ width:'52px', height:'52px', borderRadius:'16px', background:'#FEF2F2', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 14px' }}>
            <AlertTriangle size={24} style={{ color:'#EF4444' }} />
          </div>
          <h3 style={{ fontSize:'16px', fontWeight:700, color:'#0F172A', marginBottom:'8px' }}>학생을 삭제할까요?</h3>
          <p style={{ fontSize:'13px', color:'#64748B', lineHeight:1.6 }}>
            <strong style={{ color:'#0F172A' }}>{student.name}</strong> 학생의 모든 정보가<br />영구적으로 삭제됩니다.
          </p>
        </div>
        <div style={{ display:'flex', gap:'10px' }}>
          <button onClick={onClose} style={{ flex:1, padding:'12px', borderRadius:'12px', border:'1.5px solid #E2E8F0', background:'#fff', fontSize:'14px', fontWeight:600, color:'#64748B', cursor:'pointer' }}>취소</button>
          <button onClick={onConfirm} disabled={loading} style={{ flex:1, padding:'12px', borderRadius:'12px', border:'none', background: loading ? '#FCA5A5' : '#EF4444', fontSize:'14px', fontWeight:700, color:'#fff', cursor: loading ? 'not-allowed' : 'pointer' }}>
            {loading ? '삭제 중…' : '삭제하기'}
          </button>
        </div>
      </div>
    </div>
  )
}

function Field({ label, required, error, children }) {
  return (
    <div>
      <label style={{ display:'block', fontSize:'12px', fontWeight:700, color:'#374151', marginBottom:'6px' }}>
        {label}{required && <span style={{ color:'#EF4444', marginLeft:'2px' }}>*</span>}
      </label>
      {children}
      {error && <p style={{ fontSize:'11px', color:'#EF4444', marginTop:'4px' }}>{error}</p>}
    </div>
  )
}

function Toast({ msg, type }) {
  return (
    <div style={{
      position:'fixed', top:'20px', right:'20px', zIndex:100,
      display:'flex', alignItems:'center', gap:'10px',
      padding:'12px 18px', borderRadius:'14px',
      background: type==='success' ? '#10B981' : '#EF4444',
      color:'#fff', fontSize:'13px', fontWeight:600,
      boxShadow:'0 8px 24px rgba(0,0,0,0.12)',
    }}>
      <CheckCircle size={15} /> {msg}
    </div>
  )
}
